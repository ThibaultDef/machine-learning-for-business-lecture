# Load data
data = pd.read_csv("StockESG0.csv")

# Data preprocessing
data = data.dropna()  # Drop rows with missing values

data['Date'] = pd.to_datetime(data['Date'])  # Ensure the Date column is in datetime format

# Feature selection (using past prices, net income, and ESG scores)
features = ['Open_1', 'Close_1', 'Open_2', 'Close_2', 'Open_3', 'Close_3',
            'Net income', 'ESG Score', 'ESG Controversies Score',
            'Environmental Controversies Count', 'Human Rights Controversies',
            'Business Ethics Controversies', 'Wages Working Condition Controversies Count',
            'Total Renewable Energy To Energy Use in million',
            'Estimated CO2 Equivalents Emission Total']

target = 'Close'  # Predicting the current closing price

X = data[features]
y = data[target]

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Models
models = {
    'Linear Regression': LinearRegression(),
    'Support Vector Regression': SVR(kernel='rbf'),
    'Decision Tree': DecisionTreeRegressor(random_state=42),
    'Neural Network': MLPRegressor(hidden_layer_sizes=(64, 64), max_iter=500, random_state=42)
}

# Train and evaluate models
results = {}
for name, model in models.items():
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    score = r2_score(y_test, predictions)
    results[name] = score

# Display results
print("Model Performance (R^2 Score):")
for model_name, score in results.items():
    print(f"{model_name}: {score:.4f}")

# Identify most impactful variables
from sklearn.feature_selection import f_regression

f_values, p_values = f_regression(X, y)
feature_importance = pd.DataFrame({
    'Feature': features,
    'F-Value': f_values,
    'P-Value': p_values
}).sort_values(by='F-Value', ascending=False)

print("\nFeature Importance:")
print(feature_importance)

# Selecting top 2 features
top_features = feature_importance['Feature'].head(2).values
print(f"\nTop Features: {top_features}")

# Train a model with only the top 2 features
X_top = data[top_features]
X_train_top, X_test_top, y_train_top, y_test_top = train_test_split(X_top, y, test_size=0.2, random_state=42)

# Using Linear Regression as an example
linear_model = LinearRegression()
linear_model.fit(X_train_top, y_train_top)
predictions_top = linear_model.predict(X_test_top)
score_top = r2_score(y_test_top, predictions_top)

print(f"\nLinear Regression with Top Features R^2 Score: {score_top:.4f}")
