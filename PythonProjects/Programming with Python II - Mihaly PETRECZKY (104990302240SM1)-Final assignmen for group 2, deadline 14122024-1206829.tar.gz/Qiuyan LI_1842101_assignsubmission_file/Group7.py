#Group 7 (ZuerLi ID: 0298661,Qiuyan Li ID029579,LUONG Thi Lan Hue ID: 0300577)
# -*- coding: utf-8 -*-
import pandas as pd

# Read the CSV file
df = pd.read_csv('tech_companies_stock_prices.csv')

# View the first few rows of the data
print(df.head())

# Check the basic information of the data
print(df.info())

# Convert the 'Date' column to datetime type
df['Date'] = pd.to_datetime(df['Date'])

# Sort by company name and date
df = df.sort_values(by=['Stock_name', 'Date'])

# Fill missing values, or you can choose to drop them
df.fillna(method='ffill', inplace=True)

# Generate lag features (Past k days for Open and Close)
for i in range(1, 6):
    df[f'Open_{i}'] = df.groupby('Stock_name')['Open'].shift(i)
    df[f'Close_{i}'] = df.groupby('Stock_name')['Close'].shift(i)

# Drop unnecessary columns, keep only the relevant ones for prediction
df = df.drop(columns=['Unnamed: 0'])

# Drop rows with missing values
df = df.dropna()

# View the preprocessed data
print(df.head())

from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error

# Select features and labels
X = df[['Open_1', 'Close_1', 'Open_2', 'Close_2', 'Open_3', 'Close_3', 'Open_4', 'Close_4', 'Open_5', 'Close_5']]
y_open = df['Open']
y_close = df['Close']

# Split into training and testing sets
X_train, X_test, y_train_open, y_test_open = train_test_split(X, y_open, test_size=0.2, random_state=42)
X_train, X_test, y_train_close, y_test_close = train_test_split(X, y_close, test_size=0.2, random_state=42)

# Train the model for 'Open' price prediction
model_open = LinearRegression()
model_open.fit(X_train, y_train_open)

# Train the model for 'Close' price prediction
model_close = LinearRegression()
model_close.fit(X_train, y_train_close)

# Make predictions
y_pred_open = model_open.predict(X_test)
y_pred_close = model_close.predict(X_test)

# Evaluate the model
print("Open Prediction - MAE:", mean_absolute_error(y_test_open, y_pred_open))
print("Close Prediction - MAE:", mean_absolute_error(y_test_close, y_pred_close))

from sklearn.svm import SVR

# Create and train Support Vector Regression (SVR) model
svm_open = SVR()
svm_open.fit(X_train, y_train_open)

svm_close = SVR()
svm_close.fit(X_train, y_train_close)

# Make predictions using SVR
y_pred_open_svm = svm_open.predict(X_test)
y_pred_close_svm = svm_close.predict(X_test)

# Evaluate the SVR model
print("Open Prediction (SVM) - MAE:", mean_absolute_error(y_test_open, y_pred_open_svm))
print("Close Prediction (SVM) - MAE:", mean_absolute_error(y_test_close, y_pred_close_svm))

from sklearn.tree import DecisionTreeRegressor

# Create and train Decision Tree model
tree_open = DecisionTreeRegressor()
tree_open.fit(X_train, y_train_open)

tree_close = DecisionTreeRegressor()
tree_close.fit(X_train, y_train_close)

# Make predictions using Decision Tree
y_pred_open_tree = tree_open.predict(X_test)
y_pred_close_tree = tree_close.predict(X_test)

# Evaluate the Decision Tree model
print("Open Prediction (Decision Tree) - MAE:", mean_absolute_error(y_test_open, y_pred_open_tree))
print("Close Prediction (Decision Tree) - MAE:", mean_absolute_error(y_test_close, y_pred_close_tree))

from sklearn.neural_network import MLPRegressor

# Create and train Neural Network model
mlp_open = MLPRegressor(hidden_layer_sizes=(100,), max_iter=1000)
mlp_open.fit(X_train, y_train_open)

mlp_close = MLPRegressor(hidden_layer_sizes=(100,), max_iter=1000)
mlp_close.fit(X_train, y_train_close)

# Make predictions using Neural Network
y_pred_open_mlp = mlp_open.predict(X_test)
y_pred_close_mlp = mlp_close.predict(X_test)

# Evaluate the Neural Network model
print("Open Prediction (MLP) - MAE:", mean_absolute_error(y_test_open, y_pred_open_mlp))
print("Close Prediction (MLP) - MAE:", mean_absolute_error(y_test_close, y_pred_close_mlp))

from sklearn.feature_selection import SelectKBest, f_regression

# Use univariate statistical tests to select the best features
selector = SelectKBest(f_regression, k=5)
X_new = selector.fit_transform(X, y_open)

# View the selected features
print("Selected Features:", X.columns[selector.get_support()])
