#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Nov 25 22:46:28 2024

@author: Ranjie CAO & Ruge ZHANG
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.svm import SVR
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import os
import matplotlib.pyplot as plt

# Load data
data = pd.read_csv('/Users/pro/Downloads/stock_data_for_hw1.csv')

# Define target and past features
targets = ['Open', 'Close', 'High', 'Low']
past_features = [
    'Open_1', 'Close_1', 'High_1', 'Low_1',
    'Open_2', 'Close_2', 'High_2', 'Low_2',
    'Open_3', 'Close_3', 'High_3', 'Low_3',
    'Open_4', 'Close_4', 'High_4', 'Low_4',
    'Open_5', 'Close_5', 'High_5', 'Low_5'
]

# Define assisting companies and target company
assisting_companies = ['AMP', 'AME', 'AMGN']
target_company = 'AWK'

# Create output folder
output_folder = 'output_results_awk'
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Store performance metrics
performance_metrics = []
prediction_results = [] 

# Filter data for target company (AWK) and assisting companies
awk_data = data[data['Company'] == target_company]
assisting_data = data[data['Company'].isin(assisting_companies)]

# Prepare combined features for AWK prediction
combined_features = pd.DataFrame()

# Extract past features from assisting companies
for company in assisting_companies:
    company_data = assisting_data[assisting_data['Company'] == company]
    combined_features = pd.concat([combined_features, company_data[past_features].reset_index(drop=True)], axis=1)

# Ensure combined features align with AWK data
combined_features = combined_features.iloc[:len(awk_data)].reset_index(drop=True)
awk_data = awk_data.reset_index(drop=True)

# Iterate through AWK targets
for target in targets:
    # Define features (X) and target (y)
    X = combined_features
    y = awk_data[target]
    
    # Remove rows with NaN values
    valid_indices = (~X.isna().any(axis=1) & ~y.isna()).values
    X = X.loc[valid_indices]
    y = y.loc[valid_indices]
    
    # Split into train and test sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Model 1: SVM
    svm_model = SVR()
    svm_model.fit(X_train, y_train)
    svm_predictions = svm_model.predict(X_test)
    
    # Model 2: Neural Network
    nn_model = MLPRegressor(
        hidden_layer_sizes=(128, 64, 32), 
        activation='relu',
        solver='adam',
        alpha=0.001,
        learning_rate='adaptive',
        max_iter=1000,
        random_state=42
    )
    nn_model.fit(X_train, y_train)
    nn_predictions = nn_model.predict(X_test)
    
    # Calculate performance metrics
    for model_name, predictions in zip(['SVM', 'Neural Network'], [svm_predictions, nn_predictions]):
        mse = mean_squared_error(y_test, predictions)
        mae = mean_absolute_error(y_test, predictions)
        r2 = r2_score(y_test, predictions)
        
        # Add to performance metrics list
        performance_metrics.append({
            'Company': target_company,
            'Target': target,
            'Model': model_name,
            'MSE': mse,
            'MAE': mae,
            'R2': r2
        })
    
    # Combine SVM and Neural Network predictions with true values
    for i in range(len(y_test)):
        prediction_results.append({
            'Company': target_company,
            'Target': target,
            'True Value': y_test.iloc[i],
            'SVM Prediction': svm_predictions[i],
            'Neural Network Prediction': nn_predictions[i]
        })
    
    # Visualize results
    plt.figure(figsize=(10, 6))
    plt.plot(y_test.values, label='True Values', color='blue', alpha=0.7)
    plt.plot(svm_predictions, label='SVM Predictions', color='orange', alpha=0.7)
    plt.plot(nn_predictions, label='Neural Network Predictions', color='green', alpha=0.7)
    plt.title(f'{target_company} - {target} Prediction (SVM and Neural Network)')
    plt.xlabel('Samples')
    plt.ylabel('Price')
    plt.legend()
    
    # Save image
    company_folder = os.path.join(output_folder, target_company)
    if not os.path.exists(company_folder):
        os.makedirs(company_folder)
    plt.savefig(os.path.join(company_folder, f'{target}_SVM_NN.png'))
    plt.close()

# Save performance metrics to CSV
performance_df = pd.DataFrame(performance_metrics)
performance_csv_path = os.path.join(output_folder, 'performance_metrics.csv')
performance_df.to_csv(performance_csv_path, index=False)

# Save prediction results to CSV
prediction_df = pd.DataFrame(prediction_results)
prediction_csv_path = os.path.join(output_folder, 'predictions_results.csv')
prediction_df.to_csv(prediction_csv_path, index=False)

print(f'Prediction completed for AWK! Performance metrics saved to {performance_csv_path}, prediction results saved to {prediction_csv_path}')