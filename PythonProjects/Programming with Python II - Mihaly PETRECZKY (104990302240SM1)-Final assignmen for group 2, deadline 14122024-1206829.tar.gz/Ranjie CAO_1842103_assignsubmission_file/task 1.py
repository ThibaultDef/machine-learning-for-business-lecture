#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Nov 24 12:57:22 2024

@author: Ranjie CAO & Ruge ZHANG
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.svm import SVR
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import os
import matplotlib.pyplot as plt

# Load data
data = pd.read_csv('/Users/pro/Downloads/stock_data_for_hw1.csv')

# Define target and past features
targets = ['Open', 'Close', 'High', 'Low']
past_features = [
    'Open_1', 'Close_1', 'High_1', 'Low_1',
    'Open_2', 'Close_2', 'High_2', 'Low_2',
    'Open_3', 'Close_3', 'High_3', 'Low_3',
    'Open_4', 'Close_4', 'High_4', 'Low_4',
    'Open_5', 'Close_5', 'High_5', 'Low_5'
]

# Create output folder
output_folder = 'output_results'
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Store performance metrics
performance_metrics = []
prediction_results = []  

# Iterate through companies
for company in data['Company'].unique():
    company_data = data[data['Company'] == company]
    
    # Iterate through targets
    for target in targets:
        # Prepare features and target
        X = company_data[past_features]
        y = company_data[target]
        
        # Remove rows with NaN values
        valid_indices = (~X.isna().any(axis=1) & ~y.isna()).values  # Ensure boolean array
        X = X.loc[valid_indices]
        y = y.loc[valid_indices]
        
        # Split into train and test sets
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # Model 1: SVM
        svm_model = SVR()
        svm_model.fit(X_train, y_train)
        svm_predictions = svm_model.predict(X_test)
        
        # Model 2: Neural Network (with detailed explanation)
        nn_model = MLPRegressor(
            hidden_layer_sizes=(128, 64, 32),
            activation='relu',
            solver='adam',
            alpha=0.001,
            learning_rate='adaptive',
            max_iter=1000,
            random_state=42
        )
        nn_model.fit(X_train, y_train)
        nn_predictions = nn_model.predict(X_test)
        
        # Calculate performance metrics
        for model_name, predictions in zip(['SVM', 'Neural Network'], [svm_predictions, nn_predictions]):
            mse = mean_squared_error(y_test, predictions)
            mae = mean_absolute_error(y_test, predictions)
            r2 = r2_score(y_test, predictions)
            
            # Add to performance metrics list
            performance_metrics.append({
                'Company': company,
                'Target': target,
                'Model': model_name,
                'MSE': mse,
                'MAE': mae,
                'R2': r2
            })
        
        # Combine SVM and Neural Network predictions with true values
        for i in range(len(y_test)):
            prediction_results.append({
                'Company': company,
                'Target': target,
                'True Value': y_test.iloc[i],
                'SVM Prediction': svm_predictions[i],
                'Neural Network Prediction': nn_predictions[i]
            })
        
        # Visualize results
        plt.figure(figsize=(10, 6))
        plt.plot(y_test.values, label='True Values', color='blue', alpha=0.7)
        plt.plot(svm_predictions, label='SVM Predictions', color='orange', alpha=0.7)
        plt.plot(nn_predictions, label='Neural Network Predictions', color='green', alpha=0.7)
        plt.title(f'{company} - {target} Prediction (SVM and Neural Network)')
        plt.xlabel('Samples')
        plt.ylabel('Price')
        plt.legend()
        
        # Save image
        company_folder = os.path.join(output_folder, company)
        if not os.path.exists(company_folder):
            os.makedirs(company_folder)
        plt.savefig(os.path.join(company_folder, f'{target}_SVM_NN.png'))
        plt.close()

# Save performance metrics to CSV
performance_df = pd.DataFrame(performance_metrics)
performance_csv_path = os.path.join(output_folder, 'performance_metrics.csv')
performance_df.to_csv(performance_csv_path, index=False)

# Save prediction results to CSV (ensuring all targets are combined)
prediction_df = pd.DataFrame(prediction_results)
prediction_csv_path = os.path.join(output_folder, 'predictions_results.csv')
prediction_df.to_csv(prediction_csv_path, index=False)

print(f'Prediction completed! Performance metrics saved to {performance_csv_path}, prediction results saved to {prediction_csv_path}')