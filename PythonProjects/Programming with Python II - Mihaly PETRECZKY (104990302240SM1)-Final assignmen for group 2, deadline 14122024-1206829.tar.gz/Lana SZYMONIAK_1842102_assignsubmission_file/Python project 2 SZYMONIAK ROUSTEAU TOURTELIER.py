﻿#Data: open, close, net income, ESG Score


import numpy as np
import pandas as pd


#We load the data from a csv file
df_esg = pd.read_csv("/kaggle/input/esg-stock/StockESG0.csv")


#We clean your data
#Find out if you have missing data
print ("Is there missing data ", df_esg.isna().any().any())
print ("Which columns contain missing data ", df_esg.isna().any()[df_esg.isna().any()])




#Find numerical columns
#Detect columns which numbers


from pandas.api.types import is_numeric_dtype
#compute the list of column labels which are numbers
colNumList=[]
colNonNumList=[]
for col in df_esg.columns:
    if (is_numeric_dtype(df_esg[col].dtype)):
        colNumList.append(col)
    else:
        colNonNumList.append(col)


print ("Columns which are number "+str(colNumList))
print ("Columns which are not numbers "+str(colNonNumList))


#We fill out missing value
df_cl=df_esg.fillna(df_esg[colNumList].mean())


#In df_cl, all missing values which belong to a column which contains
#numbers will be replaced by the mean value of the corresponding column
#If the dataset contains no columns which are not numbers, then there will be
#no more missing value. If there are columns which do not contain numbers, then
#there might still be missing value. The latter is checked below


print ("Is there any missing data left ", df_esg.isna().any().any())


#Since the data is clean now the goal is to predict stock prices 


#Create variables used for prediction, and variable to predict
# Sélection des colonnes pertinentes


target_column = 'Open'  # Variable cible
predictor_columns = [
    'Close_1', 'Open_1', 'Close_2', 'Open_2', 'Close_3', 'Open_3',
    'Close_4', 'Open_4', 'Close_5', 'Open_5', 'Net Income Incl Extra Before Distributions',
    'ESG Score', 'Estimated CO2 Equivalents Emission Total'
]


from sklearn.model_selection import train_test_split


# We split our data into training and testing set


result=train_test_split(target_column,predictor_columns, test_size=0.2) #20% for testing 
target_column=result[0]
target_column=result[1]
predictor_columns=result[2]
predictor_columns=result[3]




# We initialize the models
models = {
    "Linear Regression": LinearRegression(),
    "Support Vector Machine": SVR(kernel='rbf'),
    "Decision Tree": DecisionTreeRegressor(random_state=42),
    "Neural Network": MLPRegressor(hidden_layer_sizes=(100,), max_iter=500, random_state=42)
}


# We train and evaluate all the models
results = {}
for name, model in models.items():
    print(f"Training {name}...")
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)


    mse = mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)


    results[name] = {
        "Mean Squared Error": mse,
        "R^2 Score": r2  }
 print(f"{name} - MSE: {mse:.4f}, R^2: {r2:.4f}\n")


# We display results
print("\nModel comparison:")
for name, metrics in results.items():
 print(f"{name}: MSE = {metrics['Mean Squared Error']:.4f}, R^2 = {metrics['R^2 Score']:.4f}")


# We identify most important variables (for Decision Tree)
important_features = None
if "Decision Tree" in models:
    feature_importances = models["Decision Tree"].feature_importances_
    important_features = pd.Series(feature_importances, index=predictor_columns).sort_values(ascending=False)
 print("\nFeature importance (Decision Tree):\n", important_features)


# We select the two most important variables for simpler model evaluation
if important_features is not None:
    top_two_features = important_features.index[:2].tolist()
 print(f"\nTop 2 features: {top_two_features}")


# We need to train a simpler Linear Regression model with top two features
 X_train_simpler = X_train[top_two_features]
 X_test_simpler = X_test[top_two_features]


simpler_model = LinearRegression()
simpler_model.fit(X_train_simpler, y_train)
 y_pred_simpler = simpler_model.predict(X_test_simpler)


mse_simpler = mean_squared_error(y_test, y_pred_simpler)
r2_simpler = r2_score(y_test, y_pred_simpler)


 print(f"\nSimpler model with top 2 features - MSE: {mse_simpler:.4f}, R^2: {r2_simpler:.4f}")