#Group 6 : Maxime Yilmaz / Alexandre Paquet / Christian Cheng

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# Step 1: Load and Explore the Data
file_path = '/Users/canyilmaz/Downloads/tech_companies_stock_prices (1).csv'  # Path to the uploaded file
data = pd.read_csv(file_path)

# Inspect the data
print("Data Head:")
print(data.head())
print("\nData Info:")
print(data.info())

# Step 2: Preprocess the Data
# Drop rows with missing values (for simplicity)
data.dropna(inplace=True)

# Encode 'Stock name' if it's categorical
if data['Stock_name'].dtype == 'object':
    data['Stock_name'] = data['Stock_name'].astype('category').cat.codes


print("\nFirst step: Use various models (such as linear regression, SVM, decision trees, and neural networks) to predict share prices. Compare the models in terms of prediction accuracy to determine which model performs best.\n")


# Step 3: Feature Engineering
# Example: Predict today's opening and closing prices using past opening and closing prices
feature_columns = ['Open_1', 'Close_1', 'Open_2', 'Close_2', 'Open_3', 'Close_3', 'Open_4', 'Close_4', 'Open_5', 'Close_5']
X = data[feature_columns]  # Features
y_open = data['Open']      # Target variable for opening price
y_close = data['Close']    # Target variable for closing price

# Step 4: Split Data
X_train, X_test, y_open_train, y_open_test, y_close_train, y_close_test = train_test_split(
    X, y_open, y_close, test_size=0.2, random_state=42
)

# Step 5: Train Models
# Initialize models
models = {
    "Linear Regression": LinearRegression(),
    "Support Vector Machine": SVR(),
    "Decision Tree": DecisionTreeRegressor(),
    "Neural Network": MLPRegressor(max_iter=500)
}

# Train and evaluate each model for predicting opening prices
open_results = {}
for model_name, model in models.items():
    print(f"Training {model_name} for Opening Prices...")
    model.fit(X_train, y_open_train)
    predictions_open = model.predict(X_test)

    # Evaluate performance
    mae = mean_absolute_error(y_open_test, predictions_open)
    mse = mean_squared_error(y_open_test, predictions_open)
    r2 = r2_score(y_open_test, predictions_open)

    open_results[model_name] = {
        "MAE": mae,
        "MSE": mse,
        "R2 Score": r2
    }

# Train and evaluate each model for predicting closing prices
close_results = {}
for model_name, model in models.items():
    print(f"Training {model_name} for Closing Prices...")
    model.fit(X_train, y_close_train)
    predictions_close = model.predict(X_test)

    # Evaluate performance
    mae = mean_absolute_error(y_close_test, predictions_close)
    mse = mean_squared_error(y_close_test, predictions_close)
    r2 = r2_score(y_close_test, predictions_close)

    close_results[model_name] = {
        "MAE": mae,
        "MSE": mse,
        "R2 Score": r2
    }

# Step 6: Display Results
print("\nModel Performance for Opening Prices:")
for model_name, metrics in open_results.items():
    print(f"{model_name}:")
    print(f"  MAE: {metrics['MAE']}")
    print(f"  MSE: {metrics['MSE']}")
    print(f"  R2 Score: {metrics['R2 Score']}\n")

print("Model Performance for Closing Prices:")
for model_name, metrics in close_results.items():
    print(f"{model_name}:")
    print(f"  MAE: {metrics['MAE']}")
    print(f"  MSE: {metrics['MSE']}")
    print(f"  R2 Score: {metrics['R2 Score']}\n")

# Step 7: Analyze Results
best_model_open = max(open_results, key=lambda x: open_results[x]['R2 Score'])
best_model_close = max(close_results, key=lambda x: close_results[x]['R2 Score'])
print(f"Best performing model for Opening Prices: {best_model_open}")
print(f"Best performing model for Closing Prices: {best_model_close}")

# Step 8: Select Top Independent Variables
print("\nFinal step:  select one or two independent variables and use them to build models for predicting share prices. Identify which variables provide the best model for predicting share prices.\n")
# Use one or two independent variables for building new models
selected_features = ['Open_1', 'Close_1']  # Selecting top two variables
X_selected = data[selected_features]

# Split data again
X_train_sel, X_test_sel, y_open_train_sel, y_open_test_sel, y_close_train_sel, y_close_test_sel = train_test_split(
    X_selected, y_open, y_close, test_size=0.2, random_state=42
)

# Train and evaluate models with selected features for opening prices
selected_open_results = {}
for model_name, model in models.items():
    print(f"Training {model_name} with selected features for Opening Prices...")
    model.fit(X_train_sel, y_open_train_sel)
    predictions_open_sel = model.predict(X_test_sel)

    # Evaluate performance
    mae = mean_absolute_error(y_open_test_sel, predictions_open_sel)
    mse = mean_squared_error(y_open_test_sel, predictions_open_sel)
    r2 = r2_score(y_open_test_sel, predictions_open_sel)

    selected_open_results[model_name] = {
        "MAE": mae,
        "MSE": mse,
        "R2 Score": r2
    }

# Train and evaluate models with selected features for closing prices
selected_close_results = {}
for model_name, model in models.items():
    print(f"Training {model_name} with selected features for Closing Prices...")
    model.fit(X_train_sel, y_close_train_sel)
    predictions_close_sel = model.predict(X_test_sel)

    # Evaluate performance
    mae = mean_absolute_error(y_close_test_sel, predictions_close_sel)
    mse = mean_squared_error(y_close_test_sel, predictions_close_sel)
    r2 = r2_score(y_close_test_sel, predictions_close_sel)

    selected_close_results[model_name] = {
        "MAE": mae,
        "MSE": mse,
        "R2 Score": r2
    }

# Display results for selected features
print("\nModel Performance with Selected Features for Opening Prices:")
for model_name, metrics in selected_open_results.items():
    print(f"{model_name}:")
    print(f"  MAE: {metrics['MAE']}")
    print(f"  MSE: {metrics['MSE']}")
    print(f"  R2 Score: {metrics['R2 Score']}\n")

print("Model Performance with Selected Features for Closing Prices:")
for model_name, metrics in selected_close_results.items():
    print(f"{model_name}:")
    print(f"  MAE: {metrics['MAE']}")
    print(f"  MSE: {metrics['MSE']}")
    print(f"  R2 Score: {metrics['R2 Score']}\n")

# Identify best models with selected features
best_model_open_selected = max(selected_open_results, key=lambda x: selected_open_results[x]['R2 Score'])
best_model_close_selected = max(selected_close_results, key=lambda x: selected_close_results[x]['R2 Score'])
print(f"Best performing model with two independent variable for Opening Prices: {best_model_open_selected}")
print(f"Best performing model with two independent variable for Closing Prices: {best_model_close_selected}")
