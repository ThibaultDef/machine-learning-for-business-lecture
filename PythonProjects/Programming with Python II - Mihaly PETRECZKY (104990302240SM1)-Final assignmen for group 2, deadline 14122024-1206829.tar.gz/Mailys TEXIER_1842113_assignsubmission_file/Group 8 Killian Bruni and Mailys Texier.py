import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.multioutput import MultiOutputRegressor
import tensorflow as tf
import matplotlib.pyplot as plt
import seaborn as sns


class StockPredictor:
    def __init__(self, data_path):
        self.data = pd.read_csv(data_path)
        self.models = {
            'Linear Regression': LinearRegression(),
            'SVR': MultiOutputRegressor(SVR(kernel='rbf')),
            'Decision Tree': DecisionTreeRegressor(),
            'Random Forest': RandomForestRegressor(),
            'Neural Network': self._create_neural_network()
        }
        self.scaler = StandardScaler()
        self.imputer = SimpleImputer(strategy='mean')

    def _create_neural_network(self):
        model = tf.keras.Sequential([
            tf.keras.layers.Dense(64, activation='relu'),
            tf.keras.layers.Dropout(0.2),
            tf.keras.layers.Dense(32, activation='relu'),
            tf.keras.layers.Dropout(0.2),
            tf.keras.layers.Dense(4)  # 4 outputs for Open, Close, High, Low
        ])
        model.compile(optimizer='adam', loss='mse')
        return model

    def preprocess_data(self, company=None):
        # Filter by company if specified
        df = self.data if company is None else self.data[self.data['Company'] == company].copy()

        # Create features from historical data
        feature_columns = []
        target_columns = ['Open', 'Close', 'High', 'Low']

        # Add historical prices
        for i in range(1, 6):
            for col in target_columns:
                feature_columns.append(f'{col}_{i}')

        # Drop rows with missing dates to ensure data continuity
        df = df.sort_values('Date').reset_index(drop=True)

        X = df[feature_columns]
        y = df[target_columns]

        # Handle missing values
        X = pd.DataFrame(self.imputer.fit_transform(X), columns=X.columns)
        y = pd.DataFrame(self.imputer.fit_transform(y), columns=y.columns)

        return train_test_split(X, y, test_size=0.2, random_state=42)

    def train_and_evaluate(self, X_train, X_test, y_train, y_test):
        results = {}

        # Scale the features
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)

        for name, model in self.models.items():
            print(f"\nTraining {name}...")

            if name == 'Neural Network':
                model.fit(X_train_scaled, y_train, epochs=50, batch_size=32, verbose=0)
                y_pred = model.predict(X_test_scaled)
            else:
                model.fit(X_train_scaled, y_train)
                y_pred = model.predict(X_test_scaled)

            # Calculate metrics for each target variable
            mse = mean_squared_error(y_test, y_pred, multioutput='raw_values')
            r2 = r2_score(y_test, y_pred, multioutput='raw_values')

            results[name] = {
                'MSE': dict(zip(['Open', 'Close', 'High', 'Low'], mse)),
                'R2': dict(zip(['Open', 'Close', 'High', 'Low'], r2))
            }

        return results

    def analyze_feature_importance(self, company=None):
        X_train, X_test, y_train, y_test = self.preprocess_data(company)

        # Use Random Forest for feature importance analysis
        rf_model = RandomForestRegressor()
        rf_model.fit(X_train, y_train)

        feature_importance = pd.DataFrame({
            'feature': X_train.columns,
            'importance': rf_model.feature_importances_.mean(axis=0)
        })

        return feature_importance.sort_values('importance', ascending=False)

    def plot_predictions(self, company, target_col='Close'):
        # Filter data for the specified company
        company_data = self.data[self.data['Company'] == company].copy()

        # Prepare features and target
        feature_columns = []
        for i in range(1, 6):
            feature_columns.append(f'{target_col}_{i}')

        X = company_data[feature_columns]
        y = company_data[target_col]

        # Handle missing values
        X = pd.DataFrame(self.imputer.fit_transform(X), columns=X.columns)
        y = pd.Series(self.imputer.fit_transform(y.values.reshape(-1, 1)).ravel())

        # Split the data
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        # Scale features
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)

        # Train Random Forest for better prediction visualization
        model = RandomForestRegressor()
        model.fit(X_train_scaled, y_train)
        y_pred = model.predict(X_test_scaled)

        # Plot actual vs predicted values
        plt.figure(figsize=(10, 6))
        plt.scatter(y_test, y_pred, alpha=0.5)
        plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', lw=2)
        plt.xlabel('Actual Prices')
        plt.ylabel('Predicted Prices')
        plt.title(f'Actual vs Predicted {target_col} Prices for {company}')
        plt.tight_layout()
        plt.savefig(f'predictions_{company}_{target_col}.png')
        plt.close()


def main():
    # Initialize predictor
    predictor = StockPredictor('stock_data_for_hw1 (1).csv')

    # Get unique companies
    companies = predictor.data['Company'].unique()

    for company in companies[:3]:  # Analyze first 3 companies as example
        print(f"\nAnalyzing {company}")

        # Train and evaluate models
        X_train, X_test, y_train, y_test = predictor.preprocess_data(company)
        results = predictor.train_and_evaluate(X_train, X_test, y_train, y_test)

        # Print results
        for model_name, metrics in results.items():
            print(f"\n{model_name} Results:")
            print("MSE:", metrics['MSE'])
            print("R2:", metrics['R2'])

        # Analyze feature importance
        importance = predictor.analyze_feature_importance(company)
        print("\nTop 5 Most Important Features:")
        print(importance.head())

        # Generate prediction plots
        predictor.plot_predictions(company)


if __name__ == "__main__":
    main()
